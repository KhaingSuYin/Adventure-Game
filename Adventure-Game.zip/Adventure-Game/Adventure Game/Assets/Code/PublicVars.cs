public static class PublicVars
{
    public static bool hasKey = false;
}
